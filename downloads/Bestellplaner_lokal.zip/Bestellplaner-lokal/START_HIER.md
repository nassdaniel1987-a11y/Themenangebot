# Bestellplaner – lokal weiterarbeiten

Dieses Paket enthält die aktuelle Anwendung, ihren vollständigen Quellcode, Tests und Excel-Vorlagen. ZIP vollständig entpacken und den gesamten Ordner aufbewahren.

## Anwendung verwenden

`Bestellplaner.html` in aktuellem Chrome oder Edge öffnen. Diese Einzeldatei enthält alle Bibliotheken. Excel-Verarbeitung erfolgt auf dem Gerät; ein Konto oder Server ist dafür nicht nötig. Falls der Browser lokale HTML-Dateien sperrt, die Anwendung über den Entwicklungsserver starten (siehe unten).

`Bestellvorlage.xlsx` ist die neu gestaltete Vorlage mit den sechs bisherigen Händlern und 100 € Gesamtbudget. `Bestellvorlage_Vorschau.pdf` zeigt das Drucklayout. Über die Anwendung lassen sich eigene Händler und andere Budgetgrenzen konfigurieren.

## Mit einer lokalen KI weiterentwickeln

Diesen gesamten entpackten Ordner im KI-Codeeditor öffnen. Die KI zuerst `AGENTS.md` und `KI_UEBERGABE.md` lesen lassen. Der bearbeitbare Quellcode liegt in `bestellplaner/`; `Bestellplaner.html` ist die erzeugte Ausgabe.

Voraussetzung: Node.js 24 LTS und npm (mit Node enthalten). Für die erste Installation wird Internetzugriff auf die npm-Paketquellen benötigt. Die Anwendung benötigt zur Nutzung keine externe API, Datenbank oder Zugangsdaten.

Im Terminal des entpackten Hauptordners:

```sh
cd bestellplaner
npm ci
npm run dev -- --port 5173
```

Im Browser die vom Entwicklungsserver angezeigte lokale Adresse öffnen. Unter Windows bei einer PowerShell-Sperre für `npm.ps1` dieselben Befehle mit `npm.cmd` ausführen, z. B. `npm.cmd ci`.

## Prüfen und neue HTML-Datei erstellen

Im Unterordner `bestellplaner`:

```sh
npm test
npm run build
npm run build:html
```

- `dist/`: neu erzeugte Version für einen Webserver.
- `standalone/index.html`: neue einzelne HTML-Datei. Nach Änderungen diese Datei als neue `Bestellplaner.html` in den Hauptordner kopieren.
- Nach Änderungen an der Vorlagenerstellung in der neuen HTML-Anwendung auch eine neue Excel-Vorlage herunterladen.

`node_modules` und Git-Metadaten sind bewusst nicht im ZIP. Alle benötigten Abhängigkeiten werden über `package-lock.json` mit `npm ci` installiert; keine Änderungen an der globalen Rechnerkonfiguration nötig.

## Dateien aufbewahren

Die Anwendung kann vollständige Arbeitsstände als `.json` speichern und über „Runde öffnen“ wieder laden. Excel-Sammelbestellungen und Verteillisten sind Ausgaben, keine vollständige Sicherung. Browser-Speicher ist an Browser und Adresse gebunden. Vor einem Wechsel von Browser, HTML-Dateipfad oder Entwicklungsserver eine Runde als Datei speichern. Bereits in einem Browser gespeicherte Runden werden durch dieses Quellcodepaket nicht automatisch übertragen.

`MANIFEST_SHA256.txt` enthält Prüfsummen für die Paketdateien.
