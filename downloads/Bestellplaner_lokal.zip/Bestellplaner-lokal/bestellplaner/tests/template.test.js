import test from 'node:test';
import assert from 'node:assert/strict';
import {createTemplateWorkbook, parseWorkbook} from '../src/excel.js';
import {workbooks} from '../src/model.js';

test('Gestaltete Vorlage bleibt mit apostrophhaltigen Händlern und Gesamtbudget importierbar', async () => {
  const workbook = await createTemplateWorkbook(
    [{name: 'Müller'}, {name: "Anna's Papier"}], 'Anna Beispiel', '175.50',
  );
  for (const [name, quantity] of [['Müller', 3], ["Anna's Papier", 2]]) {
    const sheet = workbook.getWorksheet(name);
    sheet.getCell('A8').value = '00123';
    sheet.getCell('B8').value = 'Tonpapier';
    sheet.getCell('C8').value = quantity;
    sheet.getCell('D8').value = 10;
  }
  const parsed = await parseWorkbook(await workbook.xlsx.writeBuffer(), 'Vorlage.xlsx');
  assert.equal(parsed.lists.length, 2);
  assert.equal(parsed.notes.length, 0);
  assert.equal(parsed.lists[0].person, 'Anna Beispiel');
  assert.equal(parsed.lists[0].items[0].number, '00123');
  const [book] = workbooks(parsed.lists);
  assert.equal(book.sum, 5000);
  assert.equal(book.limit, 17550);
  assert.equal(workbook.getWorksheet('Müller').getCell('D48').formula, "'Müller'!D44+'Anna''s Papier'!D44");
  assert.equal(workbook.getWorksheet('Müller').getCell('D49').formula, '175.5-D48');
});
