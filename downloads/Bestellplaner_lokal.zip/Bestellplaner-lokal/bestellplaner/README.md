# Bestellplaner

Lokale Browser-Anwendung zum Erstellen von Excel-Vorlagen und Zusammenführen ausgefüllter Bestellmappen. Eigenständiges Projekt; die bisherigen Anwendungen im Repository bleiben unverändert.

## Direkt verwenden

Die erzeugte Datei `standalone/index.html` kann ohne Server per Doppelklick in einem aktuellen Chrome oder Edge geöffnet werden. Alle Bibliotheken sind eingebettet; kein Internet und keine Anmeldung nötig. Die bereitgestellte Kopie heißt `Bestellplaner.html`.

1. **Vorlage erstellen:** Bestellgrenze für die **gesamte Mappe** eingeben, Händler hinzufügen/umbenennen/entfernen, optional einen Namen vorgeben. Die Händler werden zu Excel-Tabs mit je 35 Artikelzeilen und Formeln. Gesamtsumme aller Händler und Restbudget stehen auf jedem Blatt.
2. Personen füllen die Excel-Mappe aus; der Ansprechpartner steht in C5 auf jedem genutzten Blatt.
3. **Mappen einlesen:** Mehrere .xlsx-Dateien auswählen oder ablegen, Importvorschau prüfen und übernehmen. Leere Händlerblätter werden ignoriert. Fehlerhafte Dateien oder unbekannte Blätter werden ausdrücklich gemeldet.
4. **Budget je Mappe:** Alle Händler summieren sich gegen eine gemeinsame Grenze. Über „Bearbeiten“ lassen sich Name und Budget für alle Listen einer Mappe korrigieren. Budgetüberschreitungen sind Warnungen, keine harte Exportsperre.
5. **Ansehen:** Artikeldaten und Namen korrigieren. Fehlende Namen, ungültige Mengen/Preise und fehlende Artikelbezeichnungen sperren den Export. Fehlende Artikelnummern werden als Warnung angezeigt und einzeln geführt.
6. **Sammelbestellung:** Gruppiert nach Händler und Artikelnummer. Unterschiedliche Preise oder Namen bei gleicher Nummer werden markiert und müssen vor Export korrigiert werden. Excel-Export erzeugt ein Blatt pro Händler einschließlich Personen-Zuordnung.
7. **Verteilliste:** Excel-Liste nach Person mit Spalte zum Abhaken der Ausgabe.
8. **Runde speichern / öffnen:** Eine JSON-Datei sichert die gesamte Runde. Öffnen ersetzt nach Vorschau die aktuell geöffnete Runde. Zusätzlich wird im Browser automatisch gespeichert; zum zuverlässigen Aufbewahren immer eine Rundendatei herunterladen.

Es werden keine echten Bestellungen ausgelöst, Daten hochgeladen oder ursprüngliche Excel-Dateien verändert.

## Unterstützte Excel-Dateien

Die mitgelieferte ursprüngliche Bestellformular-Vorlage und hier erzeugte Vorlagen. Spalten A–E, Überschriften in Zeile 7, Eingaben in Zeile 8–42, Ansprechpartner C5. Artikelnummern in erzeugten Vorlagen sind als Text formatiert (führende Nullen bleiben erhalten). Auf bereits numerisch gespeicherte Nummern verlorene Nullen lassen sich nicht zuverlässig zurückrechnen.

Das ausgeblendete Blatt `_Bestellplaner` speichert die Gesamtgrenze der Mappe. Bei älteren Vorlagen wird die Euro-Angabe in A2 verwendet, ersatzweise 100 €; dies wird in der Importvorschau gemeldet. Budget kann je importierter Mappe nachträglich angepasst werden. Zeilensummen werden aus Mengen und Preisen neu berechnet, nicht aus möglicherweise veralteten Excel-Formelergebnissen.

Doppelte Mappen werden anhand normalisierter Personen, Händler, Artikel, Mengen und Preise erkannt, auch unter anderem Dateinamen. Eine geänderte Mappe gilt als neuer Import: bei Ersatz einer alten Version diese vorher entfernen. Zwei absichtlich identische Mappen derselben Person werden als Dublette behandelt.

Maximal 10 MB pro Excel-Datei. Keine Makros, kein .xls-Format und kein beliebiger Excel-Aufbau. Formeln werden im Browser nicht allgemein ausgewertet; Mengen/Preise sollten als Werte eingegeben sein. Berechnete Excel-Vorlagensummen werden durch Excel beim Öffnen neu berechnet. Geld wird für Summen als ganze Cent verarbeitet.

## Entwicklung

Node.js 24 (getestet), npm 11.

```sh
cd bestellplaner
npm ci
npm run dev -- --port 5173
```

```sh
npm test
npm run build
npm run build:html
```

`build` erzeugt die Server-Version in `dist` mit bei Bedarf geladener Excel-Bibliothek. `build:html` bündelt bewusst alle Abhängigkeiten in eine direkt öffnbare HTML-Datei in `standalone`.

## Validierung

Sieben Logiktests und ein Excel-Rückimporttest: Gesamtbudget über Händlergrenzen, Summierung und Personen-Zuordnung, Preis-Konflikte, fehlende Nummern, Zahlenformate und ungültige Mengen, Dubletten sowie Rundendatei-Validierung. Zusätzlich Chromium/Playwright: echte Vorlagenerstellung, Excel-Formelprüfung, Import von zwei Personen mit je zwei Händlerlisten, Budgetüberschreitung, Dubletten, beide Excel-Exporte und deren Inhalte, Konfliktkorrektur, ungültige Eingaben, Rundendatei öffnen und Browser-Neuladen. Mobilansicht 390 × 844 ohne Seitenüberlauf; Tabellen sind horizontal scrollbar.

## Gestaltung und Sichtprüfung

Konzeptreferenz: `../dokumentation/Designreferenz.png`. Browser-Plugin war nicht verfügbar, deshalb Playwright/Chromium. Konzept und gerenderte Screenshots mit `view_image` verglichen, zusätzlich in Konzeptgröße 1488 × 1058 sowie mobil geprüft.

Verglichen: grüne Navigation mit drei Bereichen; Überschriften und Aktionsreihenfolge; Uploadbereich und Tabellenaufbau; Weiß-/Grautöne mit Grünakzenten; Abstände und Button-/Eingabefamilien; responsiver Navigationswechsel. Bewusste fachliche Abweichungen vom frühen Bild: „Mappen“ statt „Listen“ in der Kennzahl und Gesamtbudget pro Mappe statt Händlerliste, gemäß Nutzerkorrektur. Schrift- und Iconmaße sind für die funktionsreiche Browseroberfläche vereinheitlicht. Keine Rastergrafik wird als Oberfläche verwendet.

Die Einzel-HTML wurde zusätzlich nach dem Laden mit deaktiviertem Browser-Netzwerk auf Vorlagenerstellung, Import und Export geprüft. Das direkte Öffnen von `file://` ist in der verwalteten Testumgebung administrativ gesperrt und konnte dort nicht verifiziert werden. Auf einem normalen Rechner ist die Einzeldatei zum direkten Öffnen vorgesehen; alternativ über einen lokalen Webserver bereitstellen.

## Überarbeitete Excel-Vorlage

Grüner Händlerkopf, blau markierte Eingabefelder, graue berechnete Beträge, dezente Zeilenstreifen, ein separater Budgetblock für die gesamte Mappe und rote Hervorhebung bei Überschreitung. Die 35 Eingabezeilen und Importpositionen bleiben erhalten. Jeder Händler ist für eine A4-Seite im Hochformat eingerichtet; Rasterlinien sind ausgeblendet und der Tabellenkopf bleibt beim Scrollen sichtbar. Namen, Datum, Mengen und Preise sind weiterhin frei bearbeitbar.

Die Druckausgabe wurde mit LibreOffice als PDF gerendert und visuell geprüft. Sechs Standardhändler ergeben sechs Seiten. Ein ausgefüllter Test mit zwei Händlern berechnet korrekt 50 € Gesamtwert bei 40 € Limit und -10 € Restbudget. Auch Händlernamen mit Apostrophen werden im Rückimport getestet.
