export const merchants = ['Buttinette','Müller','Braun','Betzold','Buchladen','Widmaier'];
export const money = n => new Intl.NumberFormat('de-DE',{style:'currency',currency:'EUR'}).format(n/100);
export const normalize = s => String(s ?? '').trim().normalize('NFKC').toLocaleLowerCase('de');
export function number(v){
 if(typeof v==='number') return Number.isFinite(v)?v:NaN;
 let s=String(v??'').trim().replace(/\s|€/g,'');
 if(!s) return NaN;
 if(s.includes(',')) s=s.replace(/\./g,'').replace(',','.');
 return /^\d+(\.\d+)?$/.test(s)?Number(s):NaN;
}
export function issues(list){
 const out=[];
 if(!list.person.trim()) out.push('Ansprechpartner fehlt');
 for(const item of list.items){
  if(!item.name) out.push(`Zeile ${item.row}: Artikelname fehlt`);
  if(!item.number) out.push(`Zeile ${item.row}: Artikelnummer fehlt – wird einzeln geführt`);
  if(!Number.isSafeInteger(item.quantity)||item.quantity<=0) out.push(`Zeile ${item.row}: Menge muss eine positive ganze Zahl sein`);
  if(!Number.isSafeInteger(item.cents)||item.cents<0) out.push(`Zeile ${item.row}: Einzelpreis ungültig`);
 }

 return [...new Set(out)];
}
export const validItem = i => Number.isSafeInteger(i.quantity)&&i.quantity>0&&Number.isSafeInteger(i.cents)&&i.cents>=0&&!!i.name;
export const total = l => l.items.reduce((sum,i)=>sum+(validItem(i)?i.quantity*i.cents:0),0);
export function fingerprint(l){return JSON.stringify([normalize(l.person),normalize(l.merchant),l.items.map(i=>[normalize(i.number),normalize(i.name),i.quantity,i.cents]).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b)))]);}
export function aggregate(lists){
 const map=new Map(),merchantNames=new Map();
 for(const l of lists) {if(!merchantNames.has(normalize(l.merchant)))merchantNames.set(normalize(l.merchant),l.merchant);}
 for(const l of lists) for(const [idx,i] of l.items.entries()){
  if(!validItem(i)) continue;
  const key=JSON.stringify([normalize(l.merchant),i.number?normalize(i.number):`${l.id}:${idx}`,i.cents]);
  if(!map.has(key))map.set(key,{merchant:merchantNames.get(normalize(l.merchant)),number:i.number,name:i.name,cents:i.cents,quantity:0,allocations:[],names:new Set()});
  const a=map.get(key);a.quantity+=i.quantity;a.names.add(normalize(i.name));a.allocations.push({person:l.person||'Ohne Namen',quantity:i.quantity,source:l.source});
 }
 const all=[...map.values()];
 return all.map(a=>({...a,conflict:!!a.number&&all.some(b=>normalize(b.merchant)===normalize(a.merchant)&&normalize(b.number)===normalize(a.number)&&(b.cents!==a.cents||normalize(b.name)!==normalize(a.name)))||a.names.size>1})).sort((a,b)=>a.merchant.localeCompare(b.merchant,'de')||a.name.localeCompare(b.name,'de'));
}
export function validateRound(value){
 if(value?.version!==1||typeof value.name!=='string'||!Array.isArray(value.lists)||value.lists.length>2000) throw Error('Keine gültige Bestellrunde (Version 1).');
 const lists=value.lists.map(l=>{
  if(!l||!['person','merchant','source'].every(k=>typeof l[k]==='string')||!Number.isSafeInteger(l.limit)||l.limit<0||!Array.isArray(l.items)||l.items.length>10000)throw Error('Ungültige Liste in der Bestellrunde.');
  const items=l.items.map(i=>{
   if(!i||typeof i.name!=='string'||typeof i.number!=='string'||!Number.isSafeInteger(i.row))throw Error('Ungültiger Artikel in der Bestellrunde.');
   return {row:i.row,number:i.number,name:i.name,quantity:typeof i.quantity==='number'?i.quantity:null,cents:typeof i.cents==='number'?i.cents:null};
  });
  return {id:crypto.randomUUID(),person:l.person,merchant:l.merchant,source:l.source,workbookId:typeof l.workbookId==='string'?l.workbookId:l.source,limit:l.limit,items};
 });
 return {version:1,name:value.name,lists};
}

export function workbooks(lists){
 const map=new Map();for(const l of lists){const key=l.workbookId||l.source;if(!map.has(key))map.set(key,{id:key,source:l.source,person:l.person,limit:l.limit,lists:[],sum:0});const w=map.get(key);w.lists.push(l);w.sum+=total(l);}
 return [...map.values()];
}
