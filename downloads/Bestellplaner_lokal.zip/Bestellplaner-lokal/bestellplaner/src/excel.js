import {number,validItem} from './model.js';
async function excel(){return (await import('exceljs')).default;}
function text(cell){const v=cell.value;if(v==null)return '';if(typeof v==='object'){if(v.richText)return v.richText.map(x=>x.text).join('');if(v.formula||v.sharedFormula)return String(v.result??'');if(v.text)return v.text;return '';}return String(v).trim();}
export function download(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
async function save(w,name){download(new Blob([await w.xlsx.writeBuffer()],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}),name);}
function style(s,widths){s.columns=widths.map(width=>({width}));s.views=[{state:'frozen',ySplit:7}];s.pageSetup={paperSize:9,orientation:'portrait',fitToPage:true,fitToWidth:1,fitToHeight:0};}
function header(row){row.eachCell(c=>{c.font={bold:true,color:{argb:'FFFFFFFF'}};c.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF245A49'}};c.alignment={vertical:'middle',wrapText:true};});row.height=30;}
export function validateMerchants(rows){
 const seen=new Set();if(!rows.length)throw Error('Mindestens einen Händler anlegen.');
 for(const r of rows){const n=r.name.trim();if(!n||n.length>31||/[\\/*?:\[\]]/.test(n)||n.startsWith("'")||n.endsWith("'")||n.toLowerCase()==='_bestellplaner')throw Error('Händlernamen: 1–31 Zeichen, keine Zeichen \\ / * ? : [ ] und kein Apostroph am Rand.');if(seen.has(n.toLowerCase()))throw Error('Händlernamen müssen eindeutig sein.');seen.add(n.toLowerCase());const v=number(r.limit);if(!Number.isFinite(v)||v<0||v>1000000)throw Error('Bitte eine gültige Bestellgrenze zwischen 0 und 1.000.000 € eingeben.');}
}
const TEMPLATE_COLORS = {
  ink: 'FF203C34', green: 'FF245A49', muted: 'FF65786F', border: 'FFDCE6E1',
  input: 'FFF2F7FC', inputAlt: 'FFEAF2F9', computed: 'FFF3F5F4',
  computedAlt: 'FFECEFED', white: 'FFFFFFFF', lightGreen: 'FFEAF3ED',
};
const EURO_FORMAT = '#,##0.00 "€";[Red]-#,##0.00 "€";"–"';
function fillCell(cell, color) {
  cell.fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: color}};
}
function templateBand(sheet, range, value, {background, color, size = 10, bold = false} = {}) {
  sheet.mergeCells(range);
  const cell = sheet.getCell(range.split(':')[0]);
  cell.value = value;
  cell.font = {name: 'Calibri', size, bold, color: {argb: color || TEMPLATE_COLORS.ink}};
  cell.alignment = {vertical: 'middle', horizontal: 'left', indent: 1, wrapText: true};
  if (background) fillCell(cell, background);
  return cell;
}
export async function createTemplateWorkbook(rows, person, budget) {
  rows = rows.map(row => ({...row, name: row.name.trim(), limit: budget}));
  validateMerchants(rows);
  const E = await excel();
  const workbook = new E.Workbook();
  workbook.creator = 'Bestellplaner';
  workbook.subject = 'Bestellformular mit gemeinsamem Budget für alle Händler';
  workbook.calcProperties.fullCalcOnLoad = true;
  workbook.views = [{activeTab: 1, firstSheet: 1}];
  const limit = Math.round(number(budget) * 100);
  const meta = workbook.addWorksheet('_Bestellplaner', {state: 'veryHidden'});
  meta.addRow(['Bestellplaner', 1]);
  meta.addRow(['Budget gesamte Mappe in Cent', limit]);
  meta.addRow(['Händler', 'Budget in Cent']);
  const totalFormula = rows.map(row => "'" + row.name.replace(/'/g, "''") + "'!D44").join('+');
  for (const merchant of rows) {
    meta.addRow([merchant.name, limit]);
    const sheet = workbook.addWorksheet(merchant.name, {
      properties: {defaultRowHeight: 16.5, tabColor: {argb: TEMPLATE_COLORS.green}},
    });
    sheet.columns = [19, 39, 10, 18, 19].map(width => ({width}));
    sheet.views = [{state: 'frozen', ySplit: 7, activeCell: 'A8', showGridLines: false, zoomScale: 90}];
    sheet.pageSetup = {
      paperSize: 9, orientation: 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 1,
      horizontalCentered: true,
      margins: {left: 0.3, right: 0.3, top: 0.35, bottom: 0.35, header: 0.15, footer: 0.15},
    };
    // ExcelJS 4 emits unescaped apostrophes in print-area/title names.
    // These sheets use their complete used range instead (also A1:E49).
    if (!merchant.name.includes("'")) {
      sheet.pageSetup.printArea = 'A1:E49';
      sheet.pageSetup.printTitlesRow = '1:7';
    }
    sheet.headerFooter.oddFooter = '&L&8Bestellplaner · ' + merchant.name.replace(/&/g, '&&') + '&R&8Seite &P von &N';
    for (let row = 1; row <= 49; row++) {
      for (let column = 1; column <= 5; column++) {
        const cell = sheet.getCell(row, column);
        cell.font = {name: 'Calibri', size: 10, color: {argb: TEMPLATE_COLORS.ink}};
        cell.alignment = {vertical: 'middle'};
      }
    }
    templateBand(sheet, 'A1:E1', merchant.name, {
      background: TEMPLATE_COLORS.green, color: TEMPLATE_COLORS.white, size: 23, bold: true,
    });
    sheet.getRow(1).height = 36;
    templateBand(sheet, 'A2:E2', 'BESTELLFORMULAR  ·  ' + (limit / 100).toLocaleString('de-DE', {style: 'currency', currency: 'EUR'}) + ' Gesamtbudget für alle Händler zusammen', {
      background: TEMPLATE_COLORS.lightGreen, color: TEMPLATE_COLORS.green, size: 10,
    });
    sheet.getRow(2).height = 24;
    sheet.getRow(3).height = 8;
    for (const [row, label] of [[4, 'Bestelldatum'], [5, 'Name / Ansprechpartner']]) {
      templateBand(sheet, 'A' + row + ':B' + row, label, {bold: true});
      const cell = templateBand(sheet, 'C' + row + ':E' + row, row === 5 ? person.trim() : '', {
        background: TEMPLATE_COLORS.input, size: 11,
      });
      cell.border = {bottom: {style: 'thin', color: {argb: 'FFB9CCDB'}}};
      cell.note = row === 5 ? 'Bitte den vollständigen Namen auf jedem verwendeten Händlerblatt eintragen.' : 'Hier das Datum der Bestellung eintragen.';
      sheet.getRow(row).height = 25;
    }
    sheet.getCell('C4').numFmt = 'dd.mm.yyyy';
    templateBand(sheet, 'A6:E6', 'Blaue Felder ausfüllen  ·  Graue Beträge werden automatisch berechnet', {
      color: TEMPLATE_COLORS.muted, size: 9,
    });
    sheet.getRow(6).height = 25;
    sheet.getRow(7).values = ['Artikelnummer', 'Artikelname', 'Anzahl', 'Einzelpreis (€)', 'Gesamtpreis (€)'];
    header(sheet.getRow(7));
    sheet.getRow(7).eachCell((cell, column) => {
      cell.font = {name: 'Calibri', size: 10, bold: true, color: {argb: TEMPLATE_COLORS.white}};
      cell.alignment = {vertical: 'middle', horizontal: column >= 3 ? 'center' : 'left', indent: column < 3 ? 1 : 0, wrapText: true};
    });
    for (let row = 8; row <= 42; row++) {
      sheet.getRow(row).height = 16.5;
      for (let column = 1; column <= 5; column++) {
        const cell = sheet.getCell(row, column);
        const alternate = row % 2 !== 0;
        fillCell(cell, column === 5
          ? (alternate ? TEMPLATE_COLORS.computedAlt : TEMPLATE_COLORS.computed)
          : (alternate ? TEMPLATE_COLORS.inputAlt : TEMPLATE_COLORS.input));
        cell.border = {
          bottom: {style: 'hair', color: {argb: TEMPLATE_COLORS.border}},
          right: {style: 'hair', color: {argb: TEMPLATE_COLORS.border}},
        };
        cell.alignment = {vertical: 'middle', horizontal: column === 3 ? 'center' : column > 3 ? 'right' : 'left', indent: column === 3 ? 0 : 1, wrapText: column === 2};
        if (column === 5) cell.font = {name: 'Calibri', size: 10, color: {argb: TEMPLATE_COLORS.muted}};
      }
      sheet.getCell('A' + row).numFmt = '@';
      sheet.getCell('C' + row).dataValidation = {
        type: 'whole', operator: 'greaterThan', formulae: [0], allowBlank: true,
        showErrorMessage: true, errorTitle: 'Anzahl prüfen', error: 'Bitte eine positive ganze Anzahl eintragen.',
      };
      sheet.getCell('D' + row).dataValidation = {
        type: 'decimal', operator: 'greaterThanOrEqual', formulae: [0], allowBlank: true,
        showErrorMessage: true, errorTitle: 'Einzelpreis prüfen', error: 'Preis muss mindestens 0 sein.',
      };
      sheet.getCell('D' + row).numFmt = EURO_FORMAT;
      sheet.getCell('E' + row).numFmt = EURO_FORMAT;
      sheet.getCell('E' + row).value = {formula: 'IF(OR(C' + row + '="",D' + row + '=""),"",C' + row + '*D' + row + ')'};
    }
    sheet.getCell('A7').note = 'Artikelnummern als Text eingeben, damit führende Nullen erhalten bleiben.';
    sheet.getCell('E7').note = 'Wird aus Anzahl × Einzelpreis berechnet. Hier nichts eintragen.';
    sheet.getRow(43).height = 7;
    templateBand(sheet, 'A44:C44', 'SUMME · ' + merchant.name, {background: TEMPLATE_COLORS.green, color: TEMPLATE_COLORS.white, bold: true, size: 11});
    const subtotal = templateBand(sheet, 'D44:E44', {formula: 'SUM(E8:E42)'}, {background: TEMPLATE_COLORS.green, color: TEMPLATE_COLORS.white, bold: true, size: 12});
    subtotal.numFmt = EURO_FORMAT;
    subtotal.alignment = {horizontal: 'right', vertical: 'middle', indent: 1};
    sheet.getRow(44).height = 28;
    sheet.getRow(45).height = 6;
    templateBand(sheet, 'A46:E46', 'Ein Budget für die ganze Mappe: Die Beträge aller Händler werden unten zusammengerechnet.', {color: TEMPLATE_COLORS.muted, size: 9});
    sheet.getRow(46).height = 25;
    const summary = [
      [47, 'Gemeinsame Bestellgrenze', limit / 100],
      [48, 'Bestellwert aller Händler', {formula: totalFormula}],
      [49, 'NOCH VERFÜGBARES BUDGET', {formula: (limit / 100) + '-D48'}],
    ];
    for (const [row, label, value] of summary) {
      const emphasis = row === 49;
      const background = emphasis ? TEMPLATE_COLORS.lightGreen : TEMPLATE_COLORS.computed;
      templateBand(sheet, 'A' + row + ':C' + row, label, {background, bold: emphasis, size: emphasis ? 10 : 9.5});
      const cell = templateBand(sheet, 'D' + row + ':E' + row, value, {background, color: emphasis ? TEMPLATE_COLORS.green : TEMPLATE_COLORS.ink, bold: emphasis, size: emphasis ? 12 : 10});
      cell.numFmt = EURO_FORMAT;
      cell.alignment = {vertical: 'middle', horizontal: 'right', indent: 1};
      sheet.getRow(row).height = emphasis ? 27 : 21;
    }
    sheet.addConditionalFormatting({ref: 'A49:E49', rules: [{
      type: 'expression', formulae: ['$D$49<0'], priority: 1,
      style: {font: {bold: true, color: {argb: 'FF9E3028'}}, fill: {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFFFECEA'}}},
    }]});
    sheet.addConditionalFormatting({ref: 'D48:E48', rules: [{
      type: 'expression', formulae: ['$D$48>$D$47'], priority: 2,
      style: {font: {bold: true, color: {argb: 'FF9E3028'}}},
    }]});
  }
  return workbook;
}
export async function template(rows, person, budget) {
  await save(await createTemplateWorkbook(rows, person, budget), 'Bestellvorlage.xlsx');
}
export async function parseWorkbook(buffer,source){
 const E=await excel(),w=new E.Workbook();await w.xlsx.load(buffer);const meta=w.getWorksheet('_Bestellplaner');const limits=new Map();
 if(meta&&text(meta.getCell('A1'))==='Bestellplaner')meta.eachRow((r,i)=>{if(i>2)limits.set(text(r.getCell(1)),number(r.getCell(2).value));});
 const lists=[],notes=[];const workbookId=crypto.randomUUID();const workbookLimit=meta?number(meta.getCell('B2').value):NaN;
 for(const s of w.worksheets){if(s.name==='_Bestellplaner')continue;
 if(!['Artikelnummer','Artikelname','Anzahl'].every((v,i)=>text(s.getCell(7,i+1))===v)){notes.push(`${source} / ${s.name}: unbekannter Aufbau, nicht übernommen.`);continue;}
 const items=[];for(let r=8;r<=42;r++){const num=text(s.getCell(r,1)),name=text(s.getCell(r,2)),q=text(s.getCell(r,3)),price=text(s.getCell(r,4));if(![num,name,q,price].some(Boolean))continue;const rawPrice=number(price),qty=number(q);items.push({row:r,number:num,name,quantity:Number.isFinite(qty)?qty:null,cents:Number.isFinite(rawPrice)?Math.round(rawPrice*100):null});}
 if(!items.length)continue;
 let limit=Number.isSafeInteger(workbookLimit)?workbookLimit:limits.get(s.name);if(!Number.isSafeInteger(limit)||limit<0){const match=text(s.getCell('A2')).match(/([\d.,]+)\s*€/);limit=match?Math.round(number(match[1])*100):10000;notes.push(`${s.name}: Budget ${limit/100} € aus Überschrift oder Standard übernommen.`);}
 lists.push({id:crypto.randomUUID(),workbookId,source,merchant:s.name,person:text(s.getCell('C5')),limit,items});
 }
 return {lists,notes};
}
export async function exportOrders(groups,round){
 const E=await excel(),w=new E.Workbook();for(const merchant of [...new Set(groups.map(g=>g.merchant))]){let sheetName=merchant.replace(/[\\/*?:\[\]]/g,' ').replace(/^'+|'+$/g,'').trim().slice(0,31)||'Bestellung';const base=sheetName;let suffix=1;while(w.worksheets.some(s=>s.name.toLowerCase()===sheetName.toLowerCase()))sheetName=base.slice(0,26)+' '+suffix++;const s=w.addWorksheet(sheetName);s.addRow([merchant]);s.addRow([round]);s.addRow(['Artikelnummer','Artikelname','Anzahl','Einzelpreis (€)','Gesamtpreis (€)','Zuordnung']);header(s.getRow(3));s.columns=[{width:23},{width:40},{width:12},{width:20},{width:20},{width:65}];for(const g of groups.filter(x=>x.merchant===merchant)){s.addRow([g.number,g.name,g.quantity,g.cents/100,g.quantity*g.cents/100,g.allocations.map(a=>`${a.person}: ${a.quantity}`).join('; ')]);}s.getColumn(4).numFmt='#,##0.00 "€"';s.getColumn(5).numFmt='#,##0.00 "€"';s.addRow(['GESAMTSUMME','','','',{formula:`SUM(E4:E${s.rowCount})`}]);s.views=[{state:'frozen',ySplit:3}];}await save(w,'Sammelbestellung.xlsx');
}
export async function exportDistribution(lists,round){const E=await excel(),w=new E.Workbook(),s=w.addWorksheet('Verteilliste');s.addRow([round]);s.addRow(['Person','Händler','Artikelnummer','Artikelname','Anzahl','Gesamtpreis (€)','Ausgegeben']);header(s.getRow(2));s.columns=[22,22,22,40,12,20,18].map(width=>({width}));for(const l of lists)for(const i of l.items.filter(validItem))s.addRow([l.person,l.merchant,i.number,i.name,i.quantity,i.quantity*i.cents/100,'']);s.getColumn(6).numFmt='#,##0.00 "€"';await save(w,'Verteilliste.xlsx');}
