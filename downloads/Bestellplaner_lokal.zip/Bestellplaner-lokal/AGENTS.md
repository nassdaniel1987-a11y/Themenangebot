# Hinweise für die lokal weiterarbeitende KI

Dieses Projekt ist eine bestehende lokale Sammelbestell-Anwendung. Vor Änderungen `KI_UEBERGABE.md`, `START_HIER.md` und `bestellplaner/README.md` lesen. Den vorhandenen Code weiterentwickeln; die erzeugte HTML-Datei nicht als Quellcode bearbeiten.

Quellcode: `bestellplaner/`. Die wichtigste fachliche Regel: Eine Bestellgrenze gilt für eine komplette Excel-Mappe über sämtliche Händlerblätter hinweg. Händler und Budget werden in der Anwendung vor der Vorlagenerstellung festgelegt.

Bestellungen und Rundendateien sind Nutzerdaten. Vorhandene Datenformate und die Kompatibilität mit bisherigen Excel-Vorlagen bewahren oder Änderungen ausdrücklich mit dem Nutzer abstimmen. Dateien lokal verarbeiten; keine Zugangsdaten, Datenbank oder externe KI-API hinzufügen, wenn nicht angefordert.

Nach relevanten Änderungen passende Tests und Builds ausführen. Bei Änderungen an Excel-Formeln oder Tabellenpositionen Vorlagenerstellung und Rückimport gemeinsam prüfen. Die bisherige aktuelle Einzel-HTML liegt im Paket-Hauptordner; nach Änderungen mit `npm run build:html` neu erzeugen.
