# Übergabe an die lokale KI

Stand: 4. November 2026. Sprache der Anwendung und Kommunikation: Deutsch.

## Auftrag und fachliche Entscheidungen

Eine lokale HTML-Anwendung für Sammelbestellungen, ausgehend von der Excel-Datei `vorlagen/Original_Bestellformular.xlsx`. Das Projekt entstand als eigenständiger Unterordner `bestellplaner` im Repository `nassdaniel1987-a11y/Themenangebot`. Die alten Anwendungen aus diesem Repository werden für dieses Projekt nicht benötigt und sind im Paket nicht enthalten. Dieses Paket ist ein vollständiger Export des neuen Projekts einschließlich bisher unversionierter Dateien; es enthält kein Git-Repository.

- Eine ausgefüllte Excel-Mappe gehört einer Person oder Gruppe. Der Name steht im Feld Ansprechpartner.
- Die **Bestellgrenze gilt für die ganze Mappe**, also für alle Händlerblätter zusammen. 100 € sind nur die bisherige Standardvorgabe.
- Bei der Vorlagenerstellung wählt die Person, die die Vorlagen ausgibt, die Gesamtgrenze und die Händler. Jeder Händler wird ein Excel-Tab. Händler lassen sich hinzufügen, umbenennen und entfernen. Name ist bei der Vorlagenerstellung optional und kann später in Excel eingetragen werden.
- Mehrere ausgefüllte Mappen sollen gemeinsam importiert, geprüft und je Händler zusammengefasst werden.
- Gleichartige Artikel beim selben Händler werden nach Artikelnummer zusammengefasst. Die Zuordnung zu jeder Person und Menge muss erhalten bleiben.
- Die Nutzerin/der Nutzer hat Budgetprüfung, Dublettenerkennung, Konfliktprüfung, speicherbare Bestellrunden und Verteillisten ausdrücklich befürwortet.

## Implementierter Stand

React 19, Vite 6, ExcelJS 4.4, lucide-react; CSS ohne Komponentenframework. Kein Backend, keine Anmeldung, kein Supabase, keine API-Schlüssel und keine Uploads an externe Dienste. Die im alten Repository vorhandene Supabase-Seite gehört NICHT zu diesem Projekt.

- Navigation: Bestelllisten, Sammelbestellung, Verteilliste.
- Mehrfachimport von `.xlsx` per Dateiauswahl oder Drag & Drop mit Vorschau vor Übernahme.
- Verarbeitung unterstützter Händlerblätter; leere Blätter werden ignoriert, unbekannter Aufbau wird gemeldet.
- Gesamtbudget pro importierter Mappe. Namen und Budget können je Mappe geändert werden.
- Prüfansicht und Korrektur von Artikeln und Namen innerhalb der Runde; die Ursprungs-Excel-Datei wird nicht überschrieben.
- Dublettenprüfung auf normalisiertem Inhalt einer ganzen Mappe, unabhängig vom Dateinamen.
- Zusammenfassung je Händler/Artikelnummer und Erhalt der Personen-Zuordnung. Artikel ohne Nummer bleiben einzeln.
- Unterschiedliche Preise oder Bezeichnungen derselben Artikelnummer werden markiert. Diese Konflikte sowie fehlende Namen oder ungültige Artikeldaten sperren den Export. Budgetüberschreitungen und fehlende Nummern sind Warnungen.
- Sammelbestellung als `.xlsx`, ein Blatt je Händler; separate Verteilliste als `.xlsx` mit Spalte zum Abhaken.
- Versioniertes Rundenformat `.json` mit allen Listen, Namen, Preisen, Grenzen und Korrekturen. Öffnen erfolgt nach Vorschau und ersetzt die aktuelle Runde.
- Automatische lokale Browser-Sicherung unter `bestellplaner.v1`, zusätzlich explizite Rundendatei zum dauerhaften Aufbewahren.
- Einzeldatei-Build zur lokalen Nutzung (`Bestellplaner.html`).

## Aktuelle Excel-Gestaltung

Neu überarbeitet: grüner Händlerkopf, blaue Eingabefelder, graue automatische Beträge, dezente Zeilenstreifen, gesonderter gemeinsamer Budgetblock mit Restbudget und rote Hervorhebung bei Überschreitung. Ein A4-Blatt pro Händler, keine Rasterlinien, Kopfzeilen beim Scrollen fixiert. Diese Gestaltung steckt im Generator und nicht nur in der Beispielmappe.

Beispielvorlage: `Bestellvorlage.xlsx` im Paket-Hauptordner. Die ursprüngliche Datei hatte bei Buttinette fehlende E8–E15-Formeln und eine falsche Überschrift im Betzold-Blatt; eine nur um Formeln ergänzte ältere Kopie liegt ebenfalls unter `vorlagen/`.

## Quellcode-Karte

- `src/main.jsx`: App, Navigation, Vorlagendialog, Importvorschau, Prüfdialoge, lokale Speicherung, Rundendateien.
- `src/model.js`: Zahlen-/Eurodarstellung, Validierung, Gesamtsummen, Arbeitsmappen-Gruppierung, Aggregation und Dublettensignaturen.
- `src/excel.js`: ExcelJS-Import, Excel-Vorlagengenerator, Formatierung, Sammel- und Verteillistenexport.
- `src/style.css`: Gestaltung und responsive Ansicht.
- `tests/model.test.js`: sieben Logiktests.
- `tests/template.test.js`: Generator-/Rückimporttest einschließlich Apostroph im Händlernamen.
- `vite.standalone.config.js`: Konfiguration für eine vollständig eingebettete Einzel-HTML.

## Dateiverträge und Formeln

Unterstützter Excel-Aufbau: A–E, Tabellenüberschriften in Zeile 7; Artikeldaten in Zeile 8–42. A: Artikelnummer, B: Artikelname, C: Anzahl, D: Einzelpreis, E: berechneter Gesamtpreis. Ansprechpartner C5; Datum C4. Händleridentität ist der Blattname.

- E8–E42: `IF(OR(C8="",D8=""),"",C8*D8)` mit jeweiliger Zeilennummer.
- D44 (mit E44 verbunden): Händlersumme `SUM(E8:E42)`.
- D47: gemeinsame Bestellgrenze in Euro.
- D48: Summe von D44 aller Händlerblätter; Apostrophe in Namen in Formeln verdoppeln.
- D49: gemeinsame Grenze minus D48.
- Verborgenes Blatt `_Bestellplaner`: A1 Kennung, B1 Version 1; B2 Gesamtbudget in Cent. Ab Zeile 4 Händlernamen und Budget in Cent.
- Alte Vorlagen ohne diese Metadaten: Budget aus Euro-Angabe in A2, ersatzweise 100 €; Meldung in der Vorschau.
- Import berechnet Summen aus Mengen und Preisen neu und verlässt sich nicht auf Excel-Formel-Caches. Geld für Aggregation als ganze Cent.
- Artikelnummern als Text behandeln; führende Nullen erhalten.

**ExcelJS-Falle:** Version 4.4 schreibt Apostrophe in definierten Druckbereichen/-titeln falsch. Für solche Händlernamen verzichtet der Generator deshalb auf explizite Druckbereiche/-titel und verwendet den vollständigen benutzten Bereich (A1:E49). Händler mit normalen Namen bekommen explizite Druckeinstellungen.

**Formel-Caches:** Keine künstlichen Nullwerte als berechnete Ergebnisse in Summenformeln hinterlegen. Im LibreOffice-Drucktest blieben sonst veraltete Summen stehen. Aktuell sind Summenformeln ohne gecachtes Ergebnis gespeichert und werden beim Öffnen berechnet.

## Bisherige Validierung und Grenzen

Die acht Tests liefen erfolgreich. Produktionsbuild und Einzel-HTML-Build erfolgreich. Es gibt eine Größenwarnung zur ExcelJS-Bibliothek; der normale Build lädt sie bei Bedarf, die Einzeldatei enthält sie absichtlich vollständig.

Frühere Browserprüfung mit Playwright/Chromium: Vorlagenkonfiguration und Download, Import von zwei Personen mit mehreren Händlern, Gesamtbudget, Dubletten, Aggregation und Zuordnung, beide Excel-Exporte mit Inhaltsprüfung, Konfliktsperre/-korrektur, Rundenspeicherung/-öffnung, Neuladen und Mobilansicht. Der neu gestaltete Generator wurde erneut aus dem fertigen HTML auf Download und Rückimport geprüft. Drucktest mit LibreOffice: sechs Standardhändler ergeben sechs Seiten; eine Testmappe mit zwei Händlern und 40 € Limit zeigt korrekt 50 € Gesamtwert und -10 € Restbudget. Druckbilder wurden visuell geprüft.

Die einmaligen Browser-Testskripte und temporären Screenshots wurden nicht als Projekttests gespeichert. Sie sind nicht im Paket. Für weitere Browserprüfungen kann die lokale KI eigene passende Tests verwenden.

Die Einzel-HTML wurde nach dem Laden auch ohne Browser-Netzwerk getestet. Direktes `file://`-Öffnen war im verwalteten Testbrowser administrativ gesperrt und dort nicht prüfbar. Lokal in Chrome/Edge testen; Entwicklungsserver ist als Alternative verfügbar.

- Nur `.xlsx` im beschriebenen Aufbau, maximal 10 MB pro Excel-Datei. Kein `.xls`, keine Makros und kein beliebiges Spaltenlayout.
- Import liest 35 Artikelzeilen je Händler; mehr Zeilen erfordern gemeinsam angepassten Generator und Importer.
- Mengen und Preise als Werte eingeben; keine allgemeine Excel-Formelauswertung im Browser.
- Geänderte Version einer schon importierten Mappe gilt als neuer Import. Für Ersatz einer alten Version diese vorher entfernen.
- Die aggregierte Excel-Ausgabe ist nicht als Rundensicherung oder erneuter Bestelllistenimport vorgesehen.
- Neue Runden werden über Dateispeicherung/-öffnung verwaltet; es gibt noch keine eigene Rundenauswahl oder einen expliziten Button „Neue Runde“.
- Die Runden verwenden Schema-Version 1. Bei künftigen Datenmodelländerungen vorhandene JSON-Dateien migrieren und kompatibel halten.

## Sinnvolle nächste Schritte (noch nicht beauftragt)

Mit der Nutzerin/dem Nutzer weiter abstimmen: komfortables Starten/Wechseln neuer Runden, Ersetzen einer importierten Mappe durch eine neuere Version, automatische gemeinsame Namensübernahme innerhalb einer alten Mappe, verbesserte Artikel- und Konfliktsuche, dauerhafte Browser-Automationstests. Keine neue Architektur oder Cloud-Anbindung ohne Anlass einführen.

## Startprompt zum Kopieren

> Lies AGENTS.md, START_HIER.md, KI_UEBERGABE.md und bestellplaner/README.md. Prüfe danach den vorhandenen Code. Wir entwickeln diese bestehende lokale Bestellplaner-Anwendung weiter. Die Bestellgrenze gilt immer für eine ganze Excel-Mappe über alle Händler hinweg. Erhalte Excel- und JSON-Kompatibilität und starte mit npm ci und den vorhandenen Tests. Warte dann auf meine konkrete nächste Änderung; beginne nicht mit einem Neubau.
